from tkinter import *
import calendar

def outputCalendar():
    month = int(monthSpinBox.get())
    year = int(yearSpinBox.get())
    masukkanData= calendar.month(year, month)
    textField.delete(0.0, END)
    textField.insert(INSERT, masukkanData)


root = Tk()
root.resizable(0,0)
root.title("Calendar Sederhana")
root.config(bg="blue")

monthLabel = Label(root, text="month", font=("arial", 12, "bold"), bg="yellow")
monthLabel.grid()

yearLabel = Label(root, text="year", font=("arial", 12, "bold"), bg="yellow")
yearLabel.grid(row=0, column=1)

monthSpinBox = Spinbox(root, from_=1, to=12, width=8, font=("arial", 12, "bold"))
monthSpinBox.grid(row=1, column=0, padx=10)


yearSpinBox = Spinbox(root, from_=1400, to=2099, width=8, font=("arial", 12, "bold"))
yearSpinBox.grid(row=1, column=1, padx= 12)

sendButton = Button(root, text="Send", font=("arial", 12, "bold"), command=outputCalendar)
sendButton.grid(row=1, column=2, padx=10)

textField = Text(root, width=24, height=8, fg="red")
textField.grid(row=2, column=0, columnspan=3)
root.mainloop()
